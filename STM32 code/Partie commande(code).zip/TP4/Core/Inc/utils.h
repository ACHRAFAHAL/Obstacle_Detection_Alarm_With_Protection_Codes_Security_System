/*
 * utils.h
 *
 *  Created on: Nov 18, 2024
 *      Author: Ali
 */

#ifndef INC_UTILS_H_
#define INC_UTILS_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "ssd1315.h"
#include "fonts.h"

#define BUTTON_PIN GPIO_PIN_5
#define BUTTON_PORT GPIOC

void etape0(void);
void etape1(void);
void etape2(void);
void etape3(void);
void etapeD(void);
void etapeE(void);
void set_pwm_freq(TIM_HandleTypeDef *htim, uint32_t channel, uint32_t freq_hz);

void setup();
void loop();

#endif /* INC_UTILS_H_ */
