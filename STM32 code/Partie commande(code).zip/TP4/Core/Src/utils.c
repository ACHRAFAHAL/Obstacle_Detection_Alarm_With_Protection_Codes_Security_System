/*
 * utils.c
 *
 *  Created on: Nov 18, 2024
 *      Author: Ali
 */

#include <stm32l4xx_hal.h>
#include "utils.h"
#include "encoder.h"
#include "main.h"
#include "tim.h"
#include "code.h"

static int i = 0;
static int x = 0;

uint8_t bouton_prec    = 0;
uint8_t alarme_active  = 0;
uint8_t current_freq   = 0;
uint32_t last_toggle_time = 0;
const uint32_t toggle_delay = 500;

static char* caracteres[CHARACTER_LIST_LENGTH] = {
    "0","1","2","3","4","5","6","7","8","9",
    "A","B","C","D","E","F"
};

int is_equal(char** correct_code, char** test_code){
    return (correct_code[0]==test_code[0])
        && (correct_code[1]==test_code[1])
        && (correct_code[2]==test_code[2]);
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin){
    if(GPIO_Pin == GPIO_PIN_15){
        printf("\r\nButton pressed !\r\n");
        enteredCode[i] = caracteres[encoder_read()];
        i++;
    }
}

void etape0(void){
    ssd1315_Clear(SSD1315_COLOR_BLACK);
    ssd1315_Draw_String(0, 0, "ALARM OFF", &Font_11x18);
    ssd1315_Refresh();
}

void etape1(void){
    i = 0;
    enteredCode[0] = enteredCode[1] = enteredCode[2] = "X";
    while(i != 3){
        // ← keep the tone toggling while waiting
        alarm_ON();
        HAL_Delay(1);

        char CNT1[16] = "CODE 1 : ";
        strcat(CNT1, caracteres[encoder_read()]);

        ssd1315_Clear(SSD1315_COLOR_BLACK);
        char buffer_cnt1[16];
        char c1[2] = {enteredCode[0][0], 0};
        char c2[2] = {enteredCode[1][0], 0};
        char c3[2] = {enteredCode[2][0], 0};

        snprintf(buffer_cnt1, 16, "%s", CNT1);
        ssd1315_Draw_String(0, 0, buffer_cnt1, &Font_11x18);
        ssd1315_Draw_String(0, 20, c1, &Font_11x18);
        ssd1315_Draw_String(10,20, c2, &Font_11x18);
        ssd1315_Draw_String(20,20, c3, &Font_11x18);
        ssd1315_Refresh();
    }
}

void etape2(void){
    i = 0;
    enteredCode[0] = enteredCode[1] = enteredCode[2] = "X";
    while(i != 3){
        alarm_ON();
        HAL_Delay(1);

        char CNT1[16] = "CODE 2 : ";
        strcat(CNT1, caracteres[encoder_read()]);

        ssd1315_Clear(SSD1315_COLOR_BLACK);
        char buffer_cnt1[16];
        char c1[2] = {enteredCode[0][0], 0};
        char c2[2] = {enteredCode[1][0], 0};
        char c3[2] = {enteredCode[2][0], 0};

        snprintf(buffer_cnt1, 16, "%s", CNT1);
        ssd1315_Draw_String(0, 0, buffer_cnt1, &Font_11x18);
        ssd1315_Draw_String(0, 20, c1, &Font_11x18);
        ssd1315_Draw_String(10,20, c2, &Font_11x18);
        ssd1315_Draw_String(20,20, c3, &Font_11x18);
        ssd1315_Refresh();
    }
}

void etape3(void){
    i = 0;
    enteredCode[0] = enteredCode[1] = enteredCode[2] = "X";
    while(i != 3){
        alarm_ON();
        HAL_Delay(1);

        char CNT1[16] = "CODE 3 : ";
        strcat(CNT1, caracteres[encoder_read()]);

        ssd1315_Clear(SSD1315_COLOR_BLACK);
        char buffer_cnt1[16];
        char c1[2] = {enteredCode[0][0], 0};
        char c2[2] = {enteredCode[1][0], 0};
        char c3[2] = {enteredCode[2][0], 0};

        snprintf(buffer_cnt1, 16, "%s", CNT1);
        ssd1315_Draw_String(0, 0, buffer_cnt1, &Font_11x18);
        ssd1315_Draw_String(0, 20, c1, &Font_11x18);
        ssd1315_Draw_String(10,20, c2, &Font_11x18);
        ssd1315_Draw_String(20,20, c3, &Font_11x18);
        ssd1315_Refresh();
    }
}

void etapeD(void){
    i = 0;
    enteredCode[0] = enteredCode[1] = enteredCode[2] = "X";
    while(i != 3){
        alarm_ON();
        HAL_Delay(1);

        char CNT1[16] = "CODE D : ";
        strcat(CNT1, caracteres[encoder_read()]);

        ssd1315_Clear(SSD1315_COLOR_BLACK);
        char buffer_cnt1[16];
        char c1[2] = {enteredCode[0][0], 0};
        char c2[2] = {enteredCode[1][0], 0};
        char c3[2] = {enteredCode[2][0], 0};

        snprintf(buffer_cnt1, 16, "%s", CNT1);
        ssd1315_Draw_String(0, 0, buffer_cnt1, &Font_11x18);
        ssd1315_Draw_String(0, 20, c1, &Font_11x18);
        ssd1315_Draw_String(10,20, c2, &Font_11x18);
        ssd1315_Draw_String(20,20, c3, &Font_11x18);
        ssd1315_Refresh();
    }
}

void etapeE(void){
    i = 0;
    enteredCode[0] = enteredCode[1] = enteredCode[2] = "X";
    while(i != 3){
        alarm_ON();
        HAL_Delay(1);

        char CNT1[16] = "CODE E : ";
        strcat(CNT1, caracteres[encoder_read()]);

        ssd1315_Clear(SSD1315_COLOR_BLACK);
        char buffer_cnt1[16];
        char c1[2] = {enteredCode[0][0], 0};
        char c2[2] = {enteredCode[1][0], 0};
        char c3[2] = {enteredCode[2][0], 0};

        snprintf(buffer_cnt1, 16, "%s", CNT1);
        ssd1315_Draw_String(0, 0, buffer_cnt1, &Font_11x18);
        ssd1315_Draw_String(0, 20, c1, &Font_11x18);
        ssd1315_Draw_String(10,20, c2, &Font_11x18);
        ssd1315_Draw_String(20,20, c3, &Font_11x18);
        ssd1315_Refresh();
    }
}

void set_pwm_freq(TIM_HandleTypeDef *htim, uint32_t channel, uint32_t freq_hz) {
    uint32_t timer_clock = HAL_RCC_GetPCLK1Freq();
    uint32_t prescaler   = htim->Init.Prescaler + 1;
    uint32_t period      = (timer_clock / prescaler) / freq_hz;
    __HAL_TIM_SET_AUTORELOAD(htim, period - 1);
    __HAL_TIM_SET_COMPARE   (htim, channel, (period - 1) / 2);
    HAL_TIM_PWM_Start(htim, channel);
}

int alarm_ON(){
    if (!alarme_active) {
        HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);
        alarme_active    = 1;
        current_freq     = 0;
        last_toggle_time = HAL_GetTick();
    }
    uint32_t now = HAL_GetTick();
    if (now - last_toggle_time >= toggle_delay) {
        last_toggle_time = now;
        if (current_freq == 0) {
            set_pwm_freq(&htim4, TIM_CHANNEL_3, 2500);
            current_freq = 1;
        } else {
            set_pwm_freq(&htim4, TIM_CHANNEL_3, 5000);
            current_freq = 0;
        }
    }
}

void setup(){
    printf("\r\n\r\n=====================================================================\r\n");
    encoder_init(&htim2, ENCODER_MIN_VALUE, ENCODER_MAX_VALUE);
}

void loop(){
    if (x != 1){
        HAL_TIM_PWM_Stop(&htim4, TIM_CHANNEL_3);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
        alarme_active  = 0;
        current_freq   = 0;

        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
        etape0();
    }
    if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_5) == GPIO_PIN_RESET || x == 1){
        alarm_ON();
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
        etape1();
        while(i == 3){
            if(is_equal(code1, enteredCode)){
                etape2();
                if(is_equal(code2, enteredCode)){
                    etape3();
                    if(is_equal(code3, enteredCode)){
                        x = 0;
                        break;
                    }
                }
            }
            HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET);
            HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);
            etapeD();
            if(is_equal(codeD, enteredCode)){
                x = 1;
                break;
            } else {
                while(1){
                    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET);
                    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET);
                    etapeE();
                    if(is_equal(codeE, enteredCode)){
                        x = 0;
                        break;
                    }
                }
                i = 0;
            }
        }
    }
}
